# ProjectInventory
Java program that manages an inventory of products.
